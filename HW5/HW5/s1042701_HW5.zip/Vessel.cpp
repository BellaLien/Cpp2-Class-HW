//
//  Vessel.cpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include "Vessel.h"
using namespace std;


string Vessel::name()
{
    return *NAME;
}
