//
//  Carton.hpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef Carton_hpp
#define Carton_hpp

#include <iostream>
#include <string>
#include <stdio.h>
#include "Box.h"

class Carton : public Box{            
public:              
    Carton(double, double ,double ,string);  
    virtual double volumn();                             
};
#endif /* Carton_hpp */
