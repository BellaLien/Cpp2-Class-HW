//
//  Carton.cpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include <string>
//#include "Vessel.h"
//#include "Box.h"
#include "Carton.h"

Carton::Carton(double L,double W,double H, string Nammee)
{
    Lenght = L;
    Width = W;
    Height = H;
    Vessel::NAME = &Nammee;   
}                    

double Carton::volumn(){            
    vol=(Lenght-0.5)*(Width-0.5)*(Height-0.5);            
    return vol>0.0?vol:0.0;       
    
}   

