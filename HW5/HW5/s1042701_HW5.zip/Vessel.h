//
//  Vessel.hpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef Vessel_hpp
#define Vessel_hpp

#include <iostream>
#include <stdio.h>
#include <string>
using namespace std;

class Vessel {
public:
    virtual double volumn() = 0;
    string name();
//protected:
    string *pVessels;
    double vol;
    string *NAME = NULL;
    string Name;
    int i = 0;
};
#endif /* Vessel_hpp */
