//
//  Can.cpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <string>
#include "Can.h"
using namespace std;

Can::Can (double canDiameter, double canHeight, string Namee )
{
    Diameter = canDiameter;
    Height = canHeight;
    Vessel::NAME = &Namee;
}

const double Can::PI= 3.14159265;

double Can::volumn()
{
    return PI*Diameter*Diameter*Height/4;
}

