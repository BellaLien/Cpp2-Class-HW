//
//  ToughPack.cpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include <string>
//#include "Vessel.h"
//#include "Box.h"
#include "ToughPack.h"
using namespace std;

ToughPack::ToughPack(double L,double W,double H, string Nammee)
//:Box(L, W, H, Nammee)
{
    Lenght = L;
    Width = W;
    Height = H;
    Vessel::NAME = &Nammee;
}         

double ToughPack::volumn()
{   
    return (0.85*(Lenght)*(Width)*(Height));
    
} 
