//
//  Can.hpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef Can_hpp
#define Can_hpp

#include <iostream>
#include <string>
#include <stdio.h>
#include "Vessel.h"
using namespace std;

class Can: public Vessel {
public:
    Can (double, double, string);
    void getNAME();
    virtual double volumn();
    static const double PI;
protected:
    double Diameter;
    double Height;
    string NAME;
    
};
#endif /* Can_hpp */
