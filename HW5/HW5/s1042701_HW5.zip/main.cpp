//
//  main.cpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include "Vessel.h"
#include "Box.h"
#include "ToughPack.h"
#include "Carton.h"
#include "Can.h"

using namespace std;

int main()
{
    Box box(40,30,20,"Box");
    Can can(10,3,"Can");
    Carton carton(40,30,20,"Carton");
    ToughPack toughpack(40,30,20,"ToughPack");
    
    Vessel* pVessels[] = {&box, &can, &carton, &toughpack};
    
    for(int i = 0; i < sizeof pVessels / sizeof(pVessels[0]); i++)
        cout << "Volume of " << pVessels[i]->name() <<  " is " << pVessels[i]->volumn() << endl;
//    system("pause");
    return 0;
}

