//
//  Box.hpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef Box_hpp
#define Box_hpp

#include <iostream>
#include <stdio.h>
#include <string>
#include "Vessel.h"
using namespace std;

class Box: public Vessel {
public:
    Box (double LL = 1.0, double WW = 1.0, double HH = 1.0, string Name= "NoName");
    virtual double volumn();
protected:
    double Lenght;
    double Width;
    double Height;
    string *NAME;
};
#endif /* Box_hpp */
