//
//  ToughPack.hpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef ToughPack_hpp
#define ToughPack_hpp

#include <iostream>
#include <string>
#include "Box.h"
#include <stdio.h>
using namespace std;
class ToughPack : public Box{
public:               
    ToughPack(double, double, double, string);  
    virtual double volumn();      
};
#endif /* ToughPack_hpp */
