//
//  Box.cpp
//  HW5
//
//  Created by Wei-Hsuan Lien on 2018/5/7.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include "Box.h"
#include "Vessel.h"
#include <string>
using namespace std;

Box::Box(double L, double W, double H, string Nammmee)
{
    Lenght = L;
    Width = W;
    Height = H;
    Vessel::NAME = &Nammmee;
}

double Box::volumn(){
    return Lenght*Width*Height;
}


