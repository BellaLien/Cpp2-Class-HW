//
//  RPG.hpp
//  final
//
//  Created by Wei-Hsuan Lien on 2018/5/23.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef RPG_h
#define RPG_h

#include <stdio.h>
#include <iostream>
#include <string>
using namespace std;

class Hero {
    
public:
    Hero();
    Hero(string naamme, int hp, int atk);
    void GameOver();
    int reCapacity(int);
    int reAttack(int);
    string reName(string);
    string getName() const;
    int getCapacity() const;
    int getAttack() const;
    char RPGmap[12][12] =
    {{'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'},
        {'#',' ','@','M',' ',' ','@',' ','@',' ','@', '#'},
        {'#',' ','@',' ','@',' ','@',' ',' ',' ','@', '#'},
        {'#',' ','@',' ','@',' ','@',' ','@',' ','@', '#'},
        {'#',' ','@',' ','@',' ','@',' ','@',' ','@', '#'},
        {'#',' ',' ',' ','@',' ',' ',' ','@',' ',' ', '#'},
        {'#','@','@','@','@',' ','@','@','@','@','@', '#'},
        {'#',' ',' ',' ',' ',' ','@',' ',' ',' ',' ', '#'},  
        {'#',' ',' ','@','@','@','@','M','@',' ',' ', '#'}, 
        {'#',' ',' ',' ',' ',' ',' ',' ','@',' ',' ', '#'},
        {'#','@','@','@','@','@','@','@','@',' ','G', '#'},  
        {'#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#', '#'}
    };
    char Movemap[12][12];
    char walk = '\0';
    int vert = 1, horiz = 1;
private:
    string Name;
    int Capacity;
    int Attack;
};
#endif /* RPG_hpp */
