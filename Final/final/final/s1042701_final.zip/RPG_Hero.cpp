//
//  RPG.cpp
//  final
//
//  Created by Wei-Hsuan Lien on 2018/5/23.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include "RPG_Hero.h"
#include <iostream>
#include <iomanip>
#include <string>

Hero::Hero()
{
    Capacity = 30;
    Attack = 30;
}

Hero::Hero(string naamme, int hp, int atk){
    Name = naamme;
    Capacity = hp;
    Attack = atk;
    vert = 1; 
    horiz = 1;
    memset(Movemap, '\0', sizeof(char)*(12)*(12));
    Movemap[vert][horiz] = 'H';
    cout << Name << Capacity << Attack;
}

string Hero::getName() const
{
    return Name;
}

int Hero::getCapacity() const
{
    return Capacity;
}
int Hero::getAttack() const
{
    return Attack;
}

int Hero::reCapacity(int reCapacityyy)
{
    Capacity = reCapacityyy;
    return Capacity;
}

int Hero::reAttack(int reAttackk)
{
    Attack = reAttackk;
    return Attack;
}

string Hero::reName(string reNaamme)
{
    Name = reNaamme;
    return Name;
}

void Hero::GameOver()
{
    cout << "GAME\nOVER" << endl;
    exit(1);
}
