//
//  main.cpp
//  final
//
//  Created by Wei-Hsuan Lien on 2018/5/17.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include <string>
#include <iomanip>
#include "RPG_Hero.h"
#include "RPG_Monster.h"
using namespace std;

int main(int argc, const char * argv[]) {
    
    int choice = 0;
    cout << "RPG Game" << endl;
    cout << "1. New Game" << endl;
    cout << "2. Exit" << endl;
    cout << "Your Choice: ";
    cin >> choice;
    
    if (choice == 1){
        string NAME; int HP = 0, ATK = 0; 
        char OKorNOt = NULL;
        cout << "Name: "; cin >> NAME;
        cout << "HP" << setw(4) << ": "; cin >> HP;
        cout << "ATK"  << setw(3) << ": "; cin >> ATK;
        cout << endl;
        Monster Info(NAME, HP, ATK);
        cout << "OK? (y/n) : ";
        cin >> OKorNOt;
        if (OKorNOt == 'y')
            Info.StartGame();
        else if (OKorNOt == 'n')
            return 0;
    }
    else if (choice == 2)
        return 0;
    else
        cout << "No matching option!\nPLEASE ENTER ONE MORE TIME!" << endl;
    
    return 0;
}
