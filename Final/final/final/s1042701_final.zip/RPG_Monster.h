//
//  RPG_Monster.hpp
//  final
//
//  Created by Wei-Hsuan Lien on 2018/5/23.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef RPG_Monster_hpp
#define RPG_Monster_hpp

#include <stdio.h>
#include <iostream>
#include "RPG_Hero.h"
using namespace std;

class Monster : public Hero{
public:
    Monster(string, int, int);
    Monster(int);
    Monster();
    Monster(const Monster&);
    void move(char);
    void AttackMonster(const Monster&);
    void StartGame();
    void ShowInfo(int);
};
#endif /* RPG_Monster_hpp */
