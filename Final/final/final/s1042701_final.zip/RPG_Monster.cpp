//
//  RPG_Monster.cpp
//  final
//
//  Created by Wei-Hsuan Lien on 2018/5/23.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include "RPG_Monster.h"
#include "RPG_Hero.h"
#include <string>
#include <iostream>
#include <iomanip>
using namespace std;

Monster::Monster(string naamme, int hp, int atk):Hero(naamme, hp, atk){}

Monster::Monster():Hero(){}

Monster::Monster(int atk):Hero(){
    reAttack(atk);
}

Monster::Monster(const Monster& copy)
{
    reCapacity(copy.getCapacity());
    reAttack(copy.getAttack());
    reName(copy.getName());
}
void Monster::StartGame()
{
    for (int i = 0; i < 12; i++){
        for (int j = 0; j < 12; j++){
            if (RPGmap[i][j] == ' ' && Movemap[i][j] == 'H'){
                cout << Movemap[i][j];
            }
            else
                cout << RPGmap[i][j]; 
            
            if (i < 3 && j == 11)
                ShowInfo(i);
        }
        cout << endl;
    }
    cout << "Move (w/a/s/d) : ";
    cin >> walk;
    move(walk);
}
void Monster::move(char WalkDir)
{
    switch (WalkDir) {
        case 'w':
            vert--;
            if (RPGmap[vert][horiz] == ' '){
                Movemap[vert+1][horiz] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'M'){
                int atk = 0;
                cout << "Monster's Attack power: ";
                cin >> atk;
                Monster M(atk);
                AttackMonster(M);
                RPGmap[vert][horiz] = ' ';
                Movemap[vert+1][horiz] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'G'){
                GameOver();
            }
            else{
                vert++;
                cout << "Move (w/a/s/d) : ";
                cin >> walk;
                move(walk);
            }
            break;
        case 'a':
            horiz--;
            if (RPGmap[vert][horiz] == ' '){
                Movemap[vert][horiz+1] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'M'){
                int atk = 0;
                cout << "Monster's Attack power: ";
                cin >> atk;
                Monster M(atk);
                AttackMonster(M);
                RPGmap[vert][horiz] = ' ';
                Movemap[vert][horiz+1] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'G'){
                GameOver();
            }
            else{
                horiz++;
                cout << "Move (w/a/s/d) : ";
                cin >> walk;
                move(walk);
            }
            break;
        case 's':
            vert++;
            if (RPGmap[vert][horiz] == ' '){
                Movemap[vert-1][horiz] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'M'){
                int atk = 0;
                cout << "Monster's Attack power: ";
                cin >> atk;
                Monster M(atk);
                AttackMonster(M);
                RPGmap[vert][horiz] = ' ';
                Movemap[vert-1][horiz] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'G'){
                GameOver();
            }
            else{
                vert--;
                cout << "Move (w/a/s/d) : ";
                cin >> walk;
                move(walk);
            }
            break;
        case 'd':
            horiz++;
            if (RPGmap[vert][horiz] == ' '){
                Movemap[vert][horiz-1] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'M'){
                int atk = 0;
                cout << "Monster's Attack power: ";
                cin >> atk;
                Monster M(atk);
                AttackMonster(M);
                RPGmap[vert][horiz] = ' ';
                Movemap[vert][horiz-1] = ' ';
                Movemap[vert][horiz] = 'H';
            }
            else if (RPGmap[vert][horiz] == 'G'){
                GameOver();
            }
            else{
                horiz--;
                cout << "Move (w/a/s/d) : ";
                cin >> walk;
                move(walk);
            }
        default:
            break;
    }
    StartGame();
}

void Monster::ShowInfo(int show)
{
    if (show == 0)
        cout << setw(12) << "Name: " << getName();
    else if (show == 1)
        cout << setw(8) << "HP" << setw(4) << ": " << getCapacity();
    else if (show == 2)
        cout << setw(9) << "ATK" << setw(3) << ": " <<  getAttack();
}

void Monster::AttackMonster(const Monster& MM)
{
    reCapacity(getCapacity()-MM.getAttack());
    if (getCapacity() < 0){
        cout << "You have no HP!" << endl;
        GameOver();
    }
}

