//
//  List.h
//  HW2
//
//  Created by Wei-Hsuan Lien on 2018/3/19.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef List_h
#define List_h
#include "Box.h"

class Package
{
public:
    Package(Box* pNewBox);
    Box* getBox() const;
    Package* getNext() const;
    void setNext(Package* pPackage);
    
private:
    Box* pBox;
    Package* pNext;
};


class TruckLoad
{
public:
    TruckLoad(Box* pBox = 0, int count = 1);
    Box* getFirstBox();
    Box* getNextBox();
    void addBox(Box* pBox);
    
private:
    Package* pHead;
    Package* pTail;
    Package* pCurrent;
};

#endif /* List_h */
