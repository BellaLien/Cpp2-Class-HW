//
//  Box.cpp
//  HW2
//
//  Created by Wei-Hsuan Lien on 2018/3/19.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include "Box.h"

using namespace std;

Box::Box(double Length, double Breadth, double Height)
{
    length = Length;
    breadth = Breadth;
    height = Height;
}

double Box::volume()
{
    return(length*breadth*height);
}

int Box::compareVolume(Box& otherBox)
{
    double box1 = volume();
    double box2 = otherBox.volume();
    
    if (box1 > box2)
        return 1;
    else
        if (box1 < box2)
            return -1;
        else
            return 0;
}

double Box::getLength()
{
    return length;
}

double Box::getBreadth()
{
    return breadth;
}

double Box::getHeight()
{
    return height;
}
