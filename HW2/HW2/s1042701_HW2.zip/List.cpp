//
//  List.cpp
//  HW2
//
//  Created by Wei-Hsuan Lien on 2018/3/19.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
#include "List.h"

using namespace std;

Package::Package(Box* pNewBox)
    :pBox(pNewBox), pNext(0){}

Box* Package::getBox() const
{
    return pBox;
}

Package* Package::getNext() const
{
    return pNext;
}

void Package::setNext(Package* pPackage)
{
    pNext = pPackage;
}


TruckLoad::TruckLoad(Box* pBox, int count)
{
    pHead = pTail = pCurrent = 0;

    if ((count > 0) && (pBox != 0))
        for (int i = 0; i < count; i++){
            addBox(pBox+i);
        }
}

Box* TruckLoad::getFirstBox()
{
    pCurrent = pHead;
    return pCurrent -> getBox();
}

Box* TruckLoad::getNextBox()
{
    if (pCurrent)
        pCurrent = pCurrent -> getNext();
    else
        pCurrent = pHead;
    
    return pCurrent ? pCurrent -> getBox() : 0;
}

void TruckLoad::addBox(Box* pBox)
{
    Package* pPackage = new Package(pBox);
    
    if (pHead)
        pTail -> setNext(pPackage);
    else
        pHead = pPackage;
    
    pTail = pPackage;
}

