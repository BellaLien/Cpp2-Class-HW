//
//  Box.h
//  HW2
//
//  Created by Wei-Hsuan Lien on 2018/3/19.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef Box_h
#define Box_h

class Box
{
public:
    Box(double lengthValue = 1.0, double breadthValue = 1.0, double heightValue = 1.0);
    double volume();
    int compareVolume(Box& otherBox);
    double getLength();
    double getBreadth();
    double getHeight();
    
private:
    double length;
    double breadth;
    double height;
};

#endif /* Box_h */
