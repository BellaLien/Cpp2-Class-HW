//
//  Point.h
//  HW4
//
//  Created by Wei-Hsuan Lien on 2018/4/29.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#ifndef Point_h
#define Point_h

#include <stdio.h>

class Point{    // This is the base class!
public:
    Point(float, float);
    Point();
    void setX(float);
    void setY(float);
    float X = 0;
    float Y = 0;
};

class Figure{
public:
//    virtual float area() = 0;
    float AreaResult = 0;
};

class Line : public Figure{
public:
    Line (float, float, float, float);
    float area();
private:
    Point p1, p2;
};

class Rectangle : public Figure{
public:
    Rectangle(float, float, float, float);
    float area();
    
private:
    Point p1, p2;
    
};

class Triangle : public Figure{
public:
    Triangle(float, float, float, float, float, float);
    float area();    
private:
    Point p1, p2, p3;
    
};

class Circle : public Figure{
  
public:
    Circle (float, float, float, float);
    float area();
private:
    float PI = 3.1415926;
    Point p1, p2;
    float r;
    
};

#endif /* Point_h */
