//
//  Point.cpp
//  HW4
//
//  Created by Wei-Hsuan Lien on 2018/4/29.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//
#include <iostream>
#include <iomanip>
#include <cmath>
#include "Point.h"
using namespace std;
Point::Point(float x, float y){
    setX(x);
    setY(y);
}

Point::Point(){
    X = 0;
    Y = 0;
}

void Point::setX(float xx)
{
    X = xx;
}

void Point::setY(float yy)
{
    Y = yy;
}

Line::Line (float x1, float y1, float x2, float y2)
{
    p1 = Point(x1, y1);
    p2 = Point(x2, y2);
}

float Line::area(){
    return AreaResult;
}

Rectangle::Rectangle(float x1, float y1, float x2, float y2)
{
    p1 = Point(x1, y1);
    p2 = Point(x2, y2);
}

float Rectangle::area()
{
    float length,width;
    length = (p1.X > p2.X) ? p1.X-p2.X : p2.X-p1.X;
    width = (p1.Y > p2.Y) ? p1.Y-p2.Y : p2.Y-p1.Y;
    Figure::AreaResult = length*width;
    return AreaResult;
}

Triangle::Triangle(float x1, float y1, float x2, float y2, float x3, float y3)
{
    p1 = Point(x1, y1);
    p2 = Point(x2, y2);
    p2 = Point(x3, y3);
}

float Triangle::area(){
    float a,b,c,s; //分別求三個邊長
    a = sqrt((p1.X-p2.X)*(p1.X-p2.X)+(p1.Y-p2.Y)*(p1.Y-p2.Y));
    b = sqrt((p1.X-p3.X)*(p1.X-p3.X)+(p1.Y-p3.Y)*(p1.Y-p3.Y));
    c = sqrt((p2.X-p3.X)*(p2.X-p3.X)+(p2.Y-p3.Y)*(p2.Y-p3.Y));
    s = (a+b+c)/2;
    Figure::AreaResult = sqrt(s*(s-a)*(s-b)*(s-c));
    return AreaResult;  //海倫公式求三角形面積
}

Circle::Circle(float x1, float y1, float x2, float y2)
{
    p1 = Point(x1, y1);
    p2 = Point(x2, y2);
}

float Circle::area()
{
    r = sqrt((p1.X-p2.X)*(p1.X-p2.X)+(p1.Y-p2.Y)*(p1.Y-p2.Y));
    Figure::AreaResult = PI*r*r;
    return AreaResult;
}

