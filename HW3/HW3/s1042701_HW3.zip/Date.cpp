//
//  DATE.cpp
//  HW3
//
//  Created by Wei-Hsuan Lien on 2018/4/9.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include "Date.h"
#include <iostream>
using namespace std;

const int Date::days[] = { 0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

Date::Date(int M, int D, int Y)
{
    setDate(M, D, Y);
}

void Date::setDate(int M, int D, int Y)
{
    month = (M >= 1 && M <=12) ? M : 1;
    year = (Y >= 1900 && Y <= 2017)? Y : 1900;
    
    if (M == 2 && leapyear(year))
        day = (D >= 1 && D <= 29) ? D : 1;
    else
        day = (D >= 1 && D <= days[M]) ? D : 1;
}

Date &Date::operator++()    //Date &operator++();
{
    add();        //overload prefix increment operator, increment date
    return *this;
}

Date Date::operator++(int)      //Date operator++(int);
{
    Date temp = *this;
    add();
    return temp;
}

const Date &Date::operator+=(int Adays)      //const Date &operator+=(int);
{
    for (int i = 0; i < Adays; i++)
        add();
    
    return *this;
}

bool Date::leapyear(int Ayear)
{
    if (Ayear % 400 == 0 || (Ayear % 100 != 0 && Ayear % 4 == 0))
        return true;
    else
        return false;
}

bool Date::endofMonth(int Bdays) const
{
    if ( month == 2 && leapyear(year))
        return Bdays == 29;
    else
        return Bdays == days[month];
}

void Date::add(){
    
    if (!endofMonth(day))
        day++;
    else
        if (month < 12){
            month++;
            day = 1;
        }
        else{
            year++;
            month = 1;
            day = 1;
        }
}

ostream &operator<<(ostream &output, const Date &x)             //friend ostream &operator<<(ostream &, const Date &);
{
    char *Month [13] = { " ", "January" , "Febuary" , "March" , "April", "May", "June" , "July" , "August", "September" , "October", "November", "December"};
    output << Month[x.month] << " " << x.day << ", " << x.year;
    return output;
}
