//
//  main.cpp
//  HW6
//
//  Created by Wei-Hsuan Lien on 2018/5/14.
//  Copyright © 2018年 Wei-Hsuan Lien. All rights reserved.
//

#include <iostream>
using namespace std;

template<class T>
T maximum(T a[], int n)
{
    T large=a[0];
    for(int i = 1; i < n; i++)
    {
        if(a[i] > large)
        {
            large = a[i];
        }
    }
    return large;
}

int main()
{
    int grade[10]={ 78, 44, 89, 55, 45, 75, 94, 74, 83, 65};
    float height[10]={ 178.3, 164.6, 189.4, 155.8, 158.3, 175.0, 169.6, 174.2, 183.1, 165.9};

    cout << "The best score is " << maximum<int>(grade, 10) << endl;
    cout << "The maximum height is " << maximum<float>(height, 10) << endl;

    return 0;
}

